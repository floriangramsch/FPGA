#!/bin/bash
set -eu

../sim.sh ex03_clkdiv_sel_tb ./*.vhd
