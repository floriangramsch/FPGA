#!/bin/bash
set -eu

../sim.sh ex03_lfsr8_tb ./*.vhd
