#!/bin/bash
set -eu

../sim.sh ex02_debouncer_tb ./*.vhd
