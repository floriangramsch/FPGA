#!/bin/bash
set -eu

../sim.sh ex02_edge_detector_tb ./*.vhd
